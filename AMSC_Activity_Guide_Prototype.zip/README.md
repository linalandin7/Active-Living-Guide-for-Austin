# AMSC Activity Guide

A GitHub Pages-ready prototype for exploring the 126 public facility entries in the **AMSC Facilities** worksheet of `PA1_updated.xlsx`.

## Included in this prototype

- Keyword search
- Facility, activity, and school filters
- ZIP code, address, and browser-location search with 5, 10, and 15 mile radii
- Distance, cost, and name sorting
- Compact facility cards and Quick Facts dialogs
- Responsive map placeholder tied to the current filters
- Future Programs, Events, and Calendar spaces
- Austin Parks Passport challenge concepts under Challenges

## Preview locally

```bash
npm run dev
```

Open `http://127.0.0.1:4173`.

## Build for GitHub Pages

```bash
npm run build
```

The finished static site is written to `dist/`. The included GitHub Actions workflow publishes that folder whenever the `main` branch is updated and GitHub Pages is configured to use **GitHub Actions**.

## Facility data

The checked-in `data/facilities.json` and `data/facilities.js` contain only public-facing fields exported from the project workbook. Internal workbook identifiers and review fields are deliberately excluded. Replace both files when a later workbook version is approved for the website.

Facility photographs are generic placeholder images served by Unsplash and can be replaced with project-owned photography later.
