import fs from "node:fs/promises";

const sourceRoot = new URL("../", import.meta.url);
const outputRoot = new URL("../dist/", import.meta.url);
const files = ["index.html"];
const directories = ["assets", "data", "public"];

await fs.rm(outputRoot, { recursive: true, force: true });
await fs.mkdir(outputRoot, { recursive: true });
for (const file of files) {
  await fs.copyFile(new URL(file, sourceRoot), new URL(file, outputRoot));
}
for (const directory of directories) {
  await fs.cp(new URL(`${directory}/`, sourceRoot), new URL(`${directory}/`, outputRoot), {
    recursive: true,
  });
}
await fs.writeFile(new URL(".nojekyll", outputRoot), "", "utf8");
console.log("Built the GitHub Pages site in dist/.");
