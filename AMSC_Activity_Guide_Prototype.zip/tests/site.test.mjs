import assert from "node:assert/strict";
import fs from "node:fs/promises";
import test from "node:test";

const projectRoot = new URL("../", import.meta.url);

test("directory contains all 126 facility entries", async () => {
  const facilities = JSON.parse(await fs.readFile(new URL("data/facilities.json", projectRoot), "utf8"));
  assert.equal(facilities.length, 126);
  assert.ok(facilities.every((facility) => facility.name && facility.type));
});

test("public data excludes internal workbook fields", async () => {
  const facilities = JSON.parse(await fs.readFile(new URL("data/facilities.json", projectRoot), "utf8"));
  const serialized = JSON.stringify(facilities[0]);
  assert.doesNotMatch(serialized, /Facility ID|Organization ID|Review Status|Last Verified/);
});

test("page includes the approved navigation and challenges structure", async () => {
  const html = await fs.readFile(new URL("index.html", projectRoot), "utf8");
  for (const label of ["Facilities", "Programs", "Events", "Calendar", "Map", "Challenges", "Austin Parks Passport"]) {
    assert.match(html, new RegExp(label));
  }
});
